﻿Imports System.Web.Mvc
Imports System.Data
Imports System.Data.SqlClient

Namespace Controllers
    Public Class DBAccessController
        Inherits Controller

        ' GET: DBAccess
        Public Function CREATEAPI(ByVal obj As Object) As String
            Dim con As SqlConnection = New SqlConnection("Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=interview;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")
            con.Open()
            Dim cmd As SqlCommand = New SqlCommand("Insert into Product values ('" + obj.name.ToString() + "', '" + obj.categoryid.ToString() + "', '" + obj.sku.ToString() + "', '" + obj.price.ToString() + "', '" + obj.image.ToString() + "')", con)
            cmd.ExecuteNonQuery()
            con.Close()
            Return ""


        End Function

        Public Function DELETEAPI(ByVal obj As Object) As String
            Dim con As SqlConnection = New SqlConnection("Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=interview;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")
            con.Open()
            Dim cmd As SqlCommand = New SqlCommand("delete from Product where id = ' " + obj.id.ToString() + "'", con)
            cmd.ExecuteNonQuery()
            con.Close()
            Return ""


        End Function
        Public Function UPDATEAPI(ByVal obj As Object) As String
            Dim con As SqlConnection = New SqlConnection("Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=interview;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")
            con.Open()
            Dim cmd As SqlCommand = New SqlCommand("Insert into Product values ('" + obj.name.ToString() + "', '" + obj.id.ToString() + "')", con)
            cmd.ExecuteNonQuery()
            con.Close()
            Return ""


        End Function
        Public Function CREATECATEGORYAPI(ByVal obj As Object) As String
            Dim con As SqlConnection = New SqlConnection("Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=interview;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")
            con.Open()
            Dim cmd As SqlCommand = New SqlCommand("update into category set = '" + obj.name.ToString() + "' where id = '" + obj.id.ToString() + "'", con)
            cmd.ExecuteNonQuery()
            con.Close()
            Return ""


        End Function
        Public Function DELETECATEGORYAPI(ByVal obj As Object) As String
            Dim con As SqlConnection = New SqlConnection("Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=interview;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")
            con.Open()
            Dim cmd As SqlCommand = New SqlCommand("delete from category where id = ' " + obj.id.ToString() + "'", con)
            cmd.ExecuteNonQuery()
            con.Close()
            Return ""


        End Function
        Public Function UPDATECATEGORYAPI(ByVal obj As Object) As String
            Dim con As SqlConnection = New SqlConnection("Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=interview;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")
            con.Open()
            Dim cmd As SqlCommand = New SqlCommand("update into category set = '" + obj.name.ToString() + "' where id = '" + obj.id.ToString() + "'", con)
            cmd.ExecuteNonQuery()
            con.Close()
            Return ""


        End Function
        Function Index() As ActionResult
            Return View()
        End Function
    End Class
End Namespace