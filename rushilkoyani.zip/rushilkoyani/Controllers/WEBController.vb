﻿Imports System.Web.Mvc
Imports rushilkoyani.Controllers.APIController

Namespace Controllers
    Public Class WEBController
        Inherits Controller

        Dim APIControllerobj As APIController = New APIController()


        ' GET: WEB
        Public Function CREATE(ByVal obj As Object) As String
            If obj Is Nothing Then
                APIControllerobj.CREATEAPI(obj)
            Else
                Return "Error"
            End If
            Return ""
        End Function
        Public Function DELETE(ByVal obj As Object) As String
            If obj Is Nothing Then
                APIControllerobj.DELETEAPI(obj)
            Else
                Return "Error"
            End If
            Return ""
        End Function
        Public Function UPDATE(ByVal obj As Object) As String
            If obj Is Nothing Then
                APIControllerobj.UPDATEAPI(obj)
            Else
                Return "Error"
            End If
            Return ""
        End Function
        Public Function CREATECATEGORY(ByVal obj As Object) As String

            If obj Is Nothing Then
                APIControllerobj.CREATECATEGORYAPI(obj)
            Else
                Return "Error"
            End If
            Return ""
        End Function
        Public Function DELETECATEGORY(ByVal obj As Object) As String

            If obj Is Nothing Then
                APIControllerobj.DELETECATEGORYAPI(obj)
            Else
                Return "Error"
            End If
            Return ""
        End Function
        Public Function UPDATECATEGORY(ByVal obj As Object) As String

            If obj Is Nothing Then
                APIControllerobj.UPDATECATEGORYAPI(obj)
            Else
                Return "Error"
            End If
            Return ""
        End Function
        Function Index() As ActionResult
            Return View()
        End Function
    End Class
End Namespace