﻿CREATE TABLE [dbo].[product]
(
	Id INT NOT NULL PRIMARY KEY identity(1,1),
	Product_Name NVARCHAR not null,
	Category_Id NVARCHAR not null,
	SKU INT not null,
    Price INT not null,
	Product_Image nvarchar not null
)
