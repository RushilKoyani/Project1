﻿Imports System.Net
Imports System.Web.Http
Imports rushilkoyani.Controllers.DBAccessController

Namespace Controllers
    Public Class APIController
        Dim DBAccessControllerObj As DBAccessController = New DBAccessController()

        Public Function CREATEAPI(ByVal obj As Object) As String
            DBAccessControllerObj.CREATEAPI(obj)
            Return ""
        End Function
        Public Function DELETEAPI(ByVal obj As Object) As String
            DBAccessControllerObj.DELETEAPI(obj)
            Return ""
        End Function
        Public Function UPDATEAPI(ByVal obj As Object) As String
            DBAccessControllerObj.UPDATEAPI(obj)
            Return ""
        End Function
        Public Function CREATECATEGORYAPI(ByVal obj As Object) As String
            DBAccessControllerObj.CREATECATEGORYAPI(obj)
            Return ""
        End Function
        Public Function DELETECATEGORYAPI(ByVal obj As Object) As String
            DBAccessControllerObj.DELETECATEGORYAPI(obj)
            Return ""
        End Function
        Public Function UPDATECATEGORYAPI(ByVal obj As Object) As String
            DBAccessControllerObj.UPDATECATEGORYAPI(obj)
            Return ""
        End Function
    End Class
End Namespace